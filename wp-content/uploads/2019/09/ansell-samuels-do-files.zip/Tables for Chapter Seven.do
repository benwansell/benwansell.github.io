
*** Tables for Ansell Samuels (2014) Chapter Seven

*** Please Use "Ansell Samuels Chapter Seven 1880 to 1930.dta" ***

*** Code includes esttab commands to produce tables, information available at http://repec.org/bocode/e/estout/esttab.html


*** Boix-Rosato dummy (Table 7.1) ***

xtpcse totalss  democracy percapita_k log_population  yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
eststo d1

xtpcse totalss  democracy percapita_k log_population  yr1-yr5 i.ccode, pairwise hetonly correlation(ar1) 
eststo d2

xtpcse totalss  democracy percapita_k log_population LagRuralInequality yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
 eststo d3 
 
xtpcse totalss  democracy percapita_k log_population LagRuralInequality yr1-yr5  i.ccode, pairwise hetonly correlation(ar1) 
eststo d4
 
 xtpcse totalss  democracy percapita_k tradevsgdp log_population LagRuralInequality bmginiint  yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
 eststo d5 
 
xtpcse totalss  democracy percapita_k tradevsgdp log_population  LagRuralInequality bmginiint yr1-yr5  i.ccode, pairwise hetonly correlation(ar1) 
 eststo d6 
  
 xtpcse totalss  democracy percapita_k tradevsgdp log_population  LagRuralInequality c.democracy#c.LagRuralInequality  yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
eststo d7

xtpcse totalss  democracy percapita_k tradevsgdp log_population  LagRuralInequality c.democracy#c.LagRuralInequality  yr1-yr5 i.ccode, pairwise hetonly correlation(ar1) 
eststo d8 
  
xtpcse totalss  democracy percapita_k tradevsgdp log_population bmginiint c.democracy#c.bmginiint LagRuralInequality yr1-yr5 i.regcode, pairwise hetonly correlation(ar1)
eststo d9

xtpcse totalss  democracy percapita_k tradevsgdp log_population bmginiint  c.democracy#c.bmginiint LagRuralInequality  yr1-yr5 i.ccode, pairwise hetonly correlation(ar1) 
eststo d10

cd "/Users/Ben/Documents/Research/AnsellSamuelsBook/Chapters/PublicSpendingChapter/tables/"


esttab d1 d2 d3 d4 d5 d6 d7 d8 d9 d10 using "pubspend_dem_dummy.tex", label star (* 0.10 ** 0.05 *** 0.01) b(%12.3f) se(%12.3f) ///
 booktabs replace drop (yr1 yr2 yr3 yr4 yr5  *.ccode  *.regcode *.ccode)  compress scalars("N_g Countries")  sfmt(%2.0f)  nodepvars mtitles("OLS" "FE" "OLS" "FE""OLS"  "FE""OLS" "FE" "OLS" "FE") ///
 coeflabels (democracy "Democracy" percapita_k "GDP p.c." tradevsgdp "Openness" log_population "Population" bmginiint "BM Gini" c.democracy#c.bmginiint "Dem X Gini" LagRuralInequality "Rural Ineq." c.democracy#c.LagRuralInequality "Dem X RI." )

*** Polity Score (Table 7.2) ***

xtpcse totalss  polity percapita_k log_population  yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
eststo d1

xtpcse totalss  polity percapita_k log_population  yr1-yr5 i.ccode, pairwise hetonly correlation(ar1) 
eststo d2

xtpcse totalss  polity percapita_k log_population LagRuralInequality yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
 eststo d3 
 
xtpcse totalss  polity percapita_k log_population LagRuralInequality yr1-yr5  i.ccode, pairwise hetonly correlation(ar1) 
eststo d4
 
 xtpcse totalss  polity percapita_k tradevsgdp log_population LagRuralInequality bmginiint  yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
 eststo d5 
 
xtpcse totalss  polity percapita_k tradevsgdp log_population  LagRuralInequality bmginiint yr1-yr5  i.ccode, pairwise hetonly correlation(ar1) 
 eststo d6 
  
 xtpcse totalss  polity percapita_k tradevsgdp log_population  LagRuralInequality c.polity#c.LagRuralInequality  yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
eststo d7

xtpcse totalss  polity percapita_k tradevsgdp log_population  LagRuralInequality c.polity#c.LagRuralInequality  yr1-yr5 i.ccode, pairwise hetonly correlation(ar1) 
eststo d8 
  
xtpcse totalss  polity percapita_k tradevsgdp log_population bmginiint c.polity#c.bmginiint LagRuralInequality yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
eststo d9

xtpcse totalss  polity percapita_k tradevsgdp log_population bmginiint  c.polity#c.bmginiint LagRuralInequality  yr1-yr5 i.ccode, pairwise hetonly correlation(ar1) 
eststo d10


esttab d1 d2 d3 d4 d5 d6  d7 d8 d9 d10 using "pubspend_polity.tex", label star (* 0.10 ** 0.05 *** 0.01) b(%12.3f) se(%12.3f) ///
 booktabs replace drop (yr1 yr2 yr3 yr4 yr5 *.regcode *.ccode)  compress scalars("N_g Countries")  sfmt(%2.0f)  nodepvars mtitles("OLS" "FE" "OLS" "FE""OLS" "FE""OLS" "FE" "OLS" "FE") ///
 coeflabels (polity "Polity" percapita_k "GDP p.c." tradevsgdp "Openness" log_population "Population" bmginiint "BM Gini" c.polity#c.bmginiint "Pol. X Gini" LagRuralInequality "Rural Ineq." c.polity#c.LagRuralInequality "Pol. X RI." )
 
 
 
  *** TURNOUT (Table 7.3) ***
 
  xtpcse totalss  democracy voted percapita_k tradevsgdp log_population c.LagRuralInequality#c.voted LagRuralInequality yr1-yr5 i.regcode, pairwise hetonly correlation(ar1)
 eststo t1
 xtpcse totalss  democracy voted percapita_k tradevsgdp log_population bmginiint c.bmginiint#c.voted LagRuralInequality yr1-yr5 i.regcode, pairwise hetonly correlation(ar1)
  eststo t2
  xtpcse totalss  democracy voted percapita_k tradevsgdp log_population c.LagRuralInequality#c.voted LagRuralInequality yr1-yr5 i.ccode, pairwise hetonly correlation(ar1)
  eststo t3
 xtpcse totalss  democracy voted percapita_k tradevsgdp log_population bmginiint c.bmginiint#c.voted LagRuralInequality yr1-yr5 i.ccode, pairwise hetonly correlation(ar1)
  eststo t4
   xtpcse totalss  polity voted percapita_k tradevsgdp log_population c.LagRuralInequality#c.voted LagRuralInequality yr1-yr5 i.regcode, pairwise hetonly correlation(ar1)
  eststo t5
 xtpcse totalss  polity voted percapita_k tradevsgdp log_population bmginiint c.bmginiint#c.voted LagRuralInequality yr1-yr5 i.regcode, pairwise hetonly correlation(ar1)
  eststo t6
   xtpcse totalss  polity voted percapita_k tradevsgdp log_population c.LagRuralInequality#c.voted LagRuralInequality yr1-yr5 i.ccode, pairwise hetonly correlation(ar1)
  eststo t7
 xtpcse totalss  polity voted percapita_k tradevsgdp log_population bmginiint c.bmginiint#c.voted LagRuralInequality yr1-yr5 i.ccode, pairwise hetonly correlation(ar1)
  eststo t8


 	
 esttab t1 t2 t3 t4 t5 t6 t7 t8 using "pubspend_turnout.tex", label star (* 0.10 ** 0.05 *** 0.01) b(%12.3f) se(%12.3f) ///
 booktabs replace drop (yr1 yr2 yr3 yr4 yr5 *.regcode *.ccode)  compress scalars("N_g Countries")  sfmt(%2.0f)  nodepvars mtitles("OLS" "OLS" "FE" "FE" "OLS""OLS"   "FE"  "FE") ///
 coeflabels (polity "Polity" percapita_k "GDP p.c." democracy "Dem. Dummy"  tradevsgdp "Openness" log_population "Population" bmginiint "BM Gini" voted "Turnout" c.bmginiint#c.voted ///
  "Turnout X Gini" c.LagRuralInequality#c.voted "Turnout X RI" c.polity#c.bmginiint "Pol. X Gini" LagRuralInequality "Rural Ineq." c.polity#c.LagRuralInequality "Pol. X RI." ) ///
  order (democracy polity percapita_k tradevsgdp log_population voted LagRuralInequality  c.LagRuralInequality#c.voted bmginiint c.bmginiint#c.voted)
 


 *** LEFT VOTE Vote (Table 7.4) ***
 
   xtpcse totalss  democracy leftvote percapita_k tradevsgdp log_population c.LagRuralInequality#c.leftvote LagRuralInequality yr1-yr5 i.regcode, pairwise hetonly correlation(ar1)
 eststo t1
 xtpcse totalss  democracy leftvote percapita_k tradevsgdp log_population bmginiint c.bmginiint#c.leftvote LagRuralInequality yr1-yr5 i.regcode, pairwise hetonly correlation(ar1)
  eststo t2
  xtpcse totalss  democracy leftvote percapita_k tradevsgdp log_population c.LagRuralInequality#c.leftvote LagRuralInequality yr1-yr5 i.ccode, pairwise hetonly correlation(ar1)
  eststo t3
 xtpcse totalss  democracy leftvote percapita_k tradevsgdp log_population bmginiint c.bmginiint#c.leftvote LagRuralInequality yr1-yr5 i.ccode, pairwise hetonly correlation(ar1)
  eststo t4
   xtpcse totalss  polity leftvote percapita_k tradevsgdp log_population c.LagRuralInequality#c.leftvote LagRuralInequality yr1-yr5 i.regcode, pairwise hetonly correlation(ar1)
  eststo t5
 xtpcse totalss  polity leftvote percapita_k tradevsgdp log_population bmginiint c.bmginiint#c.leftvote LagRuralInequality yr1-yr5 i.regcode, pairwise hetonly correlation(ar1)
  eststo t6
   xtpcse totalss  polity leftvote percapita_k tradevsgdp log_population c.LagRuralInequality#c.leftvote LagRuralInequality yr1-yr5 i.ccode, pairwise hetonly correlation(ar1)
  eststo t7
 xtpcse totalss  polity leftvote percapita_k tradevsgdp log_population bmginiint c.bmginiint#c.leftvote LagRuralInequality yr1-yr5 i.ccode, pairwise hetonly correlation(ar1)
  eststo t8
 
 	
 esttab t1 t2 t3 t4 t5 t6 t7 t8 using "pubspend_leftvote.tex", label star (* 0.10 ** 0.05 *** 0.01) b(%12.3f) se(%12.3f) ///
 booktabs replace drop (yr1 yr2 yr3 yr4 yr5 *.regcode *.ccode)  compress scalars("N_g Countries")  sfmt(%2.0f)  nodepvars mtitles("OLS" "OLS" "FE" "FE" "OLS""OLS"   "FE"  "FE") ///
 coeflabels (polity "Polity" percapita_k "GDP p.c." democracy "Dem. Dummy"  tradevsgdp "Openness" log_population "Population" bmginiint "BM Gini" leftvote "Left Vote" c.bmginiint#c.leftvote ///
  "Left Vote X Gini" c.LagRuralInequality#c.leftvote "Left Vote X RI" c.polity#c.bmginiint "Pol. X Gini" LagRuralInequality "Rural Ineq." c.polity#c.LagRuralInequality "Pol. X RI." ) ///
  order (democracy polity percapita_k tradevsgdp log_population leftvote LagRuralInequality  c.LagRuralInequality#c.leftvote bmginiint c.bmginiint#c.leftvote)
 
 
 
  *** TYPES OF SPENDING: DEM DUMMY (Table 7.5)
 
  xtpcse welfare  democracy percapita_k tradevsgdp log_population LagRuralInequality bmginiint  c.democracy#c.bmginiint yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
 eststo t1 
 
xtpcse welfare  democracy percapita_k tradevsgdp log_population  LagRuralInequality bmginiint  c.democracy#c.bmginiint yr1-yr5  i.ccode, pairwise hetonly correlation(ar1) 
 eststo t2 
 
  xtpcse pensions  democracy percapita_k tradevsgdp log_population LagRuralInequality bmginiint  c.democracy#c.bmginiint  yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
 eststo t3 
 
xtpcse pensions  democracy percapita_k tradevsgdp log_population  LagRuralInequality bmginiint  c.democracy#c.bmginiint yr1-yr5  i.ccode, pairwise hetonly correlation(ar1) 
 eststo t4 
  
  
   xtpcse health  democracy percapita_k tradevsgdp log_population LagRuralInequality bmginiint  c.democracy#c.bmginiint  yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
 eststo t5 
 
xtpcse health  democracy percapita_k tradevsgdp log_population  LagRuralInequality bmginiint  c.democracy#c.bmginiint yr1-yr5  i.ccode, pairwise hetonly correlation(ar1) 
 eststo t6 
  
  
   xtpcse housing  democracy percapita_k tradevsgdp log_population LagRuralInequality bmginiint  c.democracy#c.bmginiint yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
 eststo t7 
 
xtpcse housing  democracy percapita_k tradevsgdp log_population  LagRuralInequality bmginiint  c.democracy#c.bmginiint yr1-yr5  i.ccode, pairwise hetonly correlation(ar1) 
 eststo t8 
  
  esttab t1 t2 t3 t4 t5 t6 t7 t8 using "types_democracy.tex", label star (* 0.10 ** 0.05 *** 0.01) b(%12.3f) se(%12.3f) ///
 booktabs replace drop (yr1 yr2 yr3 yr4 yr5 *.regcode *.ccode)  compress scalars("N_g Countries") sfmt(%2.0f)  nodepvars ///
  mtitles("Welfare OLS" "Welfare FE" "Pensions OLS" "Pensions FE" "Health OLS" "Health FE" "Housing OLS" "Housing FE") ///
 coeflabels (democracy "Democracy" percapita_k "GDP p.c." tradevsgdp "Openness" log_population "Population" bmginiint "BM Gini" c.democracy#c.bmginiint "Dem. X Gini" LagRuralInequality "Rural Ineq." c.democracy#c.LagRuralInequality "Pol. X RI." )
 
 
 
 *** TYPES OF SPENDING: POLITY (Table 7.6)
 
  xtpcse welfare  polity percapita_k tradevsgdp log_population LagRuralInequality bmginiint  c.polity#c.bmginiint yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
 eststo t1 
 
xtpcse welfare  polity percapita_k tradevsgdp log_population  LagRuralInequality bmginiint  c.polity#c.bmginiint yr1-yr5  i.ccode, pairwise hetonly correlation(ar1) 
 eststo t2 
 
  xtpcse pensions  polity percapita_k tradevsgdp log_population LagRuralInequality bmginiint  c.polity#c.bmginiint  yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
 eststo t3 
 
xtpcse pensions  polity percapita_k tradevsgdp log_population  LagRuralInequality bmginiint  c.polity#c.bmginiint yr1-yr5  i.ccode, pairwise hetonly correlation(ar1) 
 eststo t4 
  
  
   xtpcse health  polity percapita_k tradevsgdp log_population LagRuralInequality bmginiint  c.polity#c.bmginiint  yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
 eststo t5 
 
xtpcse health  polity percapita_k tradevsgdp log_population  LagRuralInequality bmginiint  c.polity#c.bmginiint yr1-yr5  i.ccode, pairwise hetonly correlation(ar1) 
 eststo t6 
  
  
   xtpcse housing  polity percapita_k tradevsgdp log_population LagRuralInequality bmginiint  c.polity#c.bmginiint yr1-yr5 i.regcode , pairwise hetonly correlation(ar1)
 eststo t7 
 
xtpcse housing  polity percapita_k tradevsgdp log_population  LagRuralInequality bmginiint  c.polity#c.bmginiint yr1-yr5  i.ccode, pairwise hetonly correlation(ar1) 
 eststo t8 
  
  esttab t1 t2 t3 t4 t5 t6 t7 t8 using "types_polity.tex", label star (* 0.10 ** 0.05 *** 0.01) b(%12.3f) se(%12.3f) ///
 booktabs replace drop (yr1 yr2 yr3 yr4 yr5 *.regcode *.ccode)  compress scalars("N_g Countries") sfmt(%2.0f)  nodepvars ///
  mtitles("Welfare OLS" "Welfare FE" "Pensions OLS" "Pensions FE" "Health OLS" "Health FE" "Housing OLS" "Housing FE") ///
 coeflabels (polity "Polity" percapita_k "GDP p.c." tradevsgdp "Openness" log_population "Population" bmginiint "BM Gini" c.polity#c.bmginiint "Pol. X Gini" LagRuralInequality "Rural Ineq." c.polity#c.LagRuralInequality "Pol. X RI." )
 
 
 *** Contemporary Data please use  Tables for Chapter Seven Contemporary.dta
 
 
*** Table 7.7 ***

xtpcse govcons   l.polity2 l.sbginiext LagRuralInequality l.logpop l.loggdpcap l.pop65 l.pop014 l.pwt_open al_eth al_l al_rel lp_mus, pairwise hetonly correlation(ar1)
eststo a5
xtpcse govcons   l.polity2 l.sbginiext LagRuralInequality  l.logpop l.loggdpcap l.pop65 l.pop014 l.pwt_open i.ccode, pairwise hetonly correlation(ar1)
eststo a6
xtpcse govcons   c.l.polity2##c.l.sbginiext  LagRuralInequality l.logpop l.loggdpcap l.pop65 l.pop014 l.pwt_open al_eth al_l al_rel lp_mus, pairwise hetonly correlation(ar1)
eststo a7
xtpcse govcons   c.l.polity2##c.l.sbginiext  LagRuralInequality l.logpop l.loggdpcap l.pop65 l.pop014 l.pwt_open i.ccode, pairwise hetonly correlation(ar1)
eststo a8

xtpcse govcons   l.polity2 l.sbginiext LagRuralInequality l.agvalue l.logpop l.loggdpcap l.pop65 l.pop014 l.pwt_open al_eth al_l al_rel lp_mus _1960s _1970s _1980s, pairwise hetonly correlation(ar1)
eststo b5
xtpcse govcons   l.polity2 l.sbginiext LagRuralInequality  l.agvalue l.logpop l.loggdpcap l.pop65 l.pop014 l.pwt_open _1960s _1970s _1980s i.ccode, pairwise hetonly correlation(ar1)
eststo b6
xtpcse govcons   c.l.polity2##c.l.sbginiext l.parrv_i l.sbginiXparrv LagRuralInequality  l.agvalue l.logpop l.loggdpcap l.pop65 l.pop014 l.pwt_open al_eth al_l al_rel lp_mus _1960s _1970s _1980s, pairwise hetonly correlation(ar1)
eststo b7
xtpcse govcons   c.l.polity2##c.l.sbginiext l.parrv_i l.sbginiXparrv LagRuralInequality l.agvalue l.logpop l.loggdpcap l.pop65 l.pop014 l.pwt_open _1960s _1970s _1980s i.ccode, pairwise hetonly correlation(ar1)
eststo b8


cd "/Users/Ben/Dropbox/AnsellSamuelsBook/Chapters/CH8 PublicSpendingChapter/tables/"

esttab a5 a6 a7 a8 b5 b6 b7 b8  using "pubspend_1950_1999.tex", replace label star (* 0.10 ** 0.05 *** 0.01) b(%12.3f) se(%12.3f) nogaps nomtitles compress scalars("N_g Countries") sfmt(%3.0f) ///
coeflabels (L.govcons "Lagged DV" L.polity2 "Polity" L.sbginiext "SB Gini" cL.polity2#cL.sbginiext  "Polity X Gini" L.agvalue "Agriculture" LagRuralInequality "Rural Inequality" L.logpop "Population (log)" ///
L.loggdpcap "GDP p.c. (log)" L.pop65 "Population $>$ 65" L.parrv_i "Turnout" L.sbginiXparrv "Turnout X Gini" L.pop014 "Population $<$ 15" L.pwt_openk "Openness" al_ethnic "Ethnic Frac." al_language "Linguistic Frac." al_religion "Religious Frac" lp_muslim80 "Muslim Pop.") ///
drop ( *.ccode  _19***) indicate ("Fixed Effects= 498.ccode"  "Decade Dummies=_1970s" )

  
